package com.cg.lab1.bean;

public enum Division {
   A(10),B(20),C(30),D(40);
   private int code;
   
   Division(int code){
	   this.code=code;
   }
}
