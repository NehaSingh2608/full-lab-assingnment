package com.cg.lab1.ui;

import com.cg.lab1.bean.Student;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Student s= new Student(101,"Neha",76.50f);
     Student s1= new Student(102,"Nimmi",76.68f);
/*     s.setStudRollNo(20);
     s.setStudName("Sunil");
     s.setStudMarks(75.80f);
     System.out.println("Student Roll number is:"+s.getStudRollNo());
     System.out.println("Student Name is:"+s.getStudName());
     System.out.println("Student Marks is:"+s.getStudMarks());
*/     
     System.out.println(s);
     System.out.println(s1 );
	}

}
