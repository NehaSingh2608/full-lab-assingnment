package com.cg.pro3.bean;

public class FactorialMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Factorial t1=new Factorial();
     Factorial t2=new Factorial();
     t1.start();
     t2.start();
	}

}